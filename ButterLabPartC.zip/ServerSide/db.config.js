module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "ButterLab", //the password to your MySql Databases
    DB: "butterlab"
};
